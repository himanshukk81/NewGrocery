export const environment={
	API_URL:{
		dev:"https://justmyroots.com/api/cre8comm/"		
	}
}

export interface Users {
    userId: number;
    id: number;
    title: string;
    body: string;
}